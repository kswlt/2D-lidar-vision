import serial
import time
from collections import deque

# #################### 可调参数 ####################
SERIAL_PORT = '/dev/ttyUSB0'  # 串口设备路径
BAUDRATE = 115200            # 波特率
ANGLE_TOLERANCE = 5          # 正前方检测角度容差±5度（考虑零位偏差）
MIN_DISTANCE = 800            # 最小有效检测距离（毫米）
MAX_DISTANCE = 15000           # 最大有效检测距离（毫米）
DEBUG_MODE = True            # 启用调试信息输出
# #################################################

class LidarProcessor:
    def __init__(self):
        self.ser = serial.Serial(SERIAL_PORT, BAUDRATE, timeout=1)
        self.buffer = bytearray()
        self.last_detect_time = 0
        self.history = deque(maxlen=10)

    def parse_packet(self, packet):
        """解析雷达数据包（已移除校验）"""
        if len(packet) < 10:
            if DEBUG_MODE: print("[解析错误] 数据包长度不足")
            return None
        
        # 包头验证
        if packet[0] != 0x66 or packet[1] != 0xAA:
            if DEBUG_MODE: print(f"[协议错误] 无效包头: {packet[0:2].hex()}")
            return None

        # 提取基础字段
        lsn = packet[3]
        payload_start = 10
        payload_end = payload_start + lsn*3
        if len(packet) < payload_end:
            if DEBUG_MODE: print(f"[长度错误] 需要{payload_end}字节，实际{len(packet)}")
            return None

        # 角度计算
        fsa = int.from_bytes(packet[4:6], 'little')
        lsa = int.from_bytes(packet[6:8], 'little')
        angle_start = (fsa >> 1) / 64.0
        angle_end = (lsa >> 1) / 64.0
        angle_diff = (angle_end - angle_start) % 360

        points = []
        for i in range(lsn):
            idx = payload_start + i*3
            if idx+2 >= len(packet):
                break

            # 距离解析
            b1, b2, b3 = packet[idx], packet[idx+1], packet[idx+2]
            distance = (b3 << 6) | (b2 >> 2)
            
            # 光强解析
            intensity = ((b2 & 0x03) << 8) | b1
            if intensity in (1022, 1023):
                continue  # 过滤干扰数据

            # 直接打印距离
            print(f"距离: {distance}mm (光强: {intensity})")

            # 角度插值
            if lsn == 1:
                angle = angle_start
            else:
                angle = (angle_start + (angle_diff * i)/(lsn-1)) % 360
            
            points.append( (angle, distance) )

        return points

    def angle_diff(self, angle):
        """计算与正前方的角度差"""
        diff = abs(angle % 360)
        return min(diff, 360 - diff)

    def run(self):
        print(f"激光雷达监控已启动，检测范围: {MIN_DISTANCE}-{MAX_DISTANCE}mm 角度容差±{ANGLE_TOLERANCE}°")
        try:
            while True:
                # 读取串口数据
                self.buffer.extend(self.ser.read(self.ser.in_waiting or 1))
                
                # 处理完整数据包
                while True:
                    start = self.buffer.find(b'\x66\xAA')
                    if start == -1: break
                    if start > 0: self.buffer = self.buffer[start:]
                    
                    if len(self.buffer) < 10: break
                    lsn = self.buffer[3]
                    payload_start = 10
                    payload_end = payload_start + lsn*3
                    pkt_len = payload_end
                    if len(self.buffer) < pkt_len: break
                    
                    packet = bytes(self.buffer[:pkt_len])
                    self.buffer = self.buffer[pkt_len:]
                    
                    points = self.parse_packet(packet)
                    if not points: continue
                    
                    # 检测逻辑
                    current_time = time.time()
                    detected = False
                    for angle, dist in points:
                        if DEBUG_MODE: 
                            print(f"[原始数据] 角度: {angle:6.2f}° 距离: {dist:4d}mm", 
                                end='\r' if len(points)>1 else '\n')
                        
                        if (self.angle_diff(angle) <= ANGLE_TOLERANCE and 
                            MIN_DISTANCE <= dist <= MAX_DISTANCE):
                            print(f"\n[检测告警] 发现目标! 距离: {dist}mm 角度: {angle:.1f}°")
                            self.last_detect_time = current_time
                            detected = True
                            break
                    
                    self.history.append(detected)
                
                # 未检测到处理
                if time.time() - self.last_detect_time >= 1.0:
                    if sum(self.history) == 0:  # 最近10次均未检测到
                        print("状态: 未检测到行人", end='\r')
                    time.sleep(0.1)
                    
        except KeyboardInterrupt:
            self.ser.close()
            print("\n监控已停止")

if __name__ == "__main__":
    lidar = LidarProcessor()
    lidar.run()
